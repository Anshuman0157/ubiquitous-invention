import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import wikipedia
import pyjokes
import os
import subprocess as sp
import webbrowser
import time
import pyautogui
from PIL import Image





engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)


chrome_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
webbrowser.register('brave', None, webbrowser.BackgroundBrowser(chrome_path))



def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning SIR")
    elif hour >= 12 and hour < 18:
        speak("Good Afternoon SIR")

    else:
        speak('Good Evening SIR')


    speak('I am JARVIS. Please tell me how can I serve you?')


def speak(text):
    engine.say(text)
    engine.runAndWait()

def screenshot():
    myScreenshot = pyautogui.screenshot()
    myScreenshot.save('screenshot.png')

def take_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print('Listening....')
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print('Recognizing...')
        query = r.recognize_google(audio, language='en-in')
        if 'jarvis' in query:
            query = query.replace('jarvis', '')
        if 'Jarvis' in query:
            query = query.replace('Jarvis', '')
    except Exception:
        speak('Sorry, I could not understand. Could you please say that again?')
        query = 'None'
    return query

paths = {
    'notepad': "C:\\Windows\\notepad.exe",
    'discord': "C:\\Users\\ashut\\AppData\\Local\\Discord\\app-1.0.9003\\Discord.exe",
    'calculator': "C:\\Windows\\System32\\calc.exe"
}


def open_notepad():
    os.startfile(paths['notepad'])
    time.sleep(5)


def open_discord():
    os.startfile(paths['discord'])
    time.sleep(5)


def open_cmd():
    os.system('start cmd')
    time.sleep(5)



def open_camera():
    sp.run('start microsoft.windows.camera:', shell=True)
    time.sleep(5)


def open_calculator():
    sp.Popen(paths['calculator'])
    time.sleep(5)


def run_jarvis():
    command = take_command()
    print(command)
    if 'play' in command:
        song = command.replace('play', '')
        speak('playing' + song)
        pywhatkit.playonyt(song)
        time.sleep(10)
    elif 'time' in command:
        time1 = datetime.datetime.now().strftime('%I:%M %p')
        print(time1)
        speak('Current time is ' + time1)
    elif 'who is' in command or 'Who is' in command:
        person = command.replace('who is' or 'Who is', '')
        info = wikipedia.summary(person, 2)
        speak('According to wikipedia')
        print(info)
        speak(info)
    elif 'I love you' in command:
        speak('i love you too sweetheart')
    elif 'are you single' in command:
        speak('No, i am married to technology')
    elif 'How are you' in command or 'how are you' in command:
        speak("Sorry!, i have a boyfriend")
    elif 'joke' in command:
        joke = pyjokes.get_joke()
        speak(joke)
    elif 'open notepad' in command or 'open Notepad' in command:
        speak('opening notepad')
        open_notepad()

    elif 'open discord' in command or 'open Discord' in command:
        speak('opening discord')
        open_discord()

    elif 'open command prompt' in command or 'open cmd' in command:
        speak('opening CMD')
        open_cmd()

    elif 'open camera' in command or 'open Camera' in command:
        speak('opening camera')
        open_camera()

    elif 'open calculator' in command or 'open Calculator' in command:
        speak('opening calculator')
        open_calculator()
    elif 'how are you' in command:
        speak('Sorry! i have a boyfriend.')
    elif 'open YouTube' in command:
        speak('opening youtube')
        webbrowser.get('brave').open_new_tab('https://youtube.com')
        time.sleep(5)

    elif 'open Amazon' in command:
        speak('opening amazon')
        webbrowser.get('brave').open_new_tab('https://amazon.com')
        time.sleep(5)
    elif 'open Moneycontrol' in command:
        speak('opening Money control')
        webbrowser.get('brave').open_new_tab('https://www.moneycontrol.com/')
        time.sleep(5)
    elif 'open Google' in command:
        speak('opening google')
        webbrowser.get('brave').open_new_tab('https://google.com')
        time.sleep(5)

    elif 'open Stackoverflow' in command:
        speak('opening stack overflow')
        webbrowser.get('brave').open_new_tab('https://stackoverflow.com')
        time.sleep(5)
    elif 'music on' in command:
        speak('playing music')
        os.startfile("G:\\man.mp3")
        time.sleep(5)
    elif 'search' in command:
        speak('What do you want to search for?')
        search = take_command()
        url = 'https://google.com/search?q=' + search
        webbrowser.get('brave').open_new_tab(
            url)
        speak('Here is What I found for' + search)
        time.sleep(5)
    elif 'made you' in command:
        speak('Vansh Malhotra and Ankush,my masters made me. They carved me from powers beyond your understanding.')
        print('Vansh Malhotra and Ankush,my masters made me. They carved me from powers beyond your understanding.')
    elif 'stand for' in command:
        speak('I stands for JUST A RATHER VERY INTELLIGENT SYSTEM')
        print('I stands for JUST A RATHER VERY INTELLIGENT SYSTEM')
    elif 'voice' in command:
        if 'female' in command:
            engine.setProperty('voice', voices[0].id)
        else:
            engine.setProperty('voice', voices[1].id)
        speak("Hello Sir, I have switched my voice. How is it?")
    elif 'the date' in command:
        year = int(datetime.datetime.now().year)
        month = int(datetime.datetime.now().month)
        date = int(datetime.datetime.now().day)
        print("the current Date is")
        print(date)
        print(month)
        print(year)
        speak("the current Date is")
        speak(date)
        speak(month)
        speak(year)

    elif 'go offline' in command or 'sleep' in command or 'shutdown' in command:
        print('shuting down')
        speak("Shutting down the system")
        quit()
    elif 'capture screenshot' in command:
        print('taking screenshot')
        speak("taking screenshot")
        screenshot()
    elif "show me the screenshot" in command:
        try:
            img = Image.open('screenshot.png')
            img.show(img)
            speak("Here it is sir")
            time.sleep(5)

        except IOError:
            speak("Sorry sir, I am unable to display the screenshot")
    elif 'wish me' in command:
        wishMe()
    else:
        speak('Hey, i didnt understand can you say it again')

wishMe()

while True:
      run_jarvis()